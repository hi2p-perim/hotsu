Supplementary data for the paper:
  "Reproducing Spectral Reflectances from Tristimulus Colors"

Included:
  - PCA basis functions for 8 clusters (in directory "PCAResult/")
  - PCA mean functions for 8 clusters (in directory "PCAResult/")
  - Reconstructed spectra for the measurement of 1269 matt Munsell color chips by Kohonen et al.
  - Reconstructed spectra for the measurement of 24 color chips in Macbeth Color Checker
  - Python code to select the corresponding cluster
