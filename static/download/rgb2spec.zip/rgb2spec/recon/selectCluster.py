def return_clus(x, y):
    if(y >= 0.333444973048471):
        if(x >= 0.428556829741043):
            if(y >= 0.368343583792887):
                return 7
            else:
                return 5
        else:
            return 1
    else:
        if(x >= 0.389059234962091):
            if(x >= 0.464102042665547):
                return 6
            else:
                return 2
        else:
            if(x >= 0.288243127874986):
                if(y >= 0.247072787814766):
                    return 4
                else:
                    return 3
            else:
                return 0